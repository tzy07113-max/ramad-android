from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Ramad API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=[], allow_credentials=False,
                   allow_methods=["GET"], allow_headers=["*"])

MODULES = [
    {"id":"commands","name":"مركز الأوامر","state":"واجهة أولية — يحتاج ربط محرك الأوامر"},
    {"id":"profile","name":"الحساب الشخصي","state":"غير مربوط — يتطلب مصادقة MTProto آمنة"},
    {"id":"search","name":"البحث والوسائط","state":"غير مربوط — يحتاج مزود بحث"},
    {"id":"groups","name":"إدارة المجموعات والقنوات","state":"غير مربوط — حسب صلاحيات الحساب"},
    {"id":"subscriptions","name":"الاشتراكات","state":"غير مربوط — يحتاج إعداد نظام الفوترة"},
]
@app.get("/health")
def health():
    return {"service":"ramad-api","status":"ok","version":"0.1.0"}
@app.get("/v1/modules")
def modules():
    return {"modules": MODULES}
