"""Safe command router scaffold. Real Telegram client/auth is intentionally not enabled."""
ALLOWED_COMMANDS = {
    ".أوامري": "show_help",
    ".مساعدة": "show_help",
    ".معرفي": "show_identity",
    ".وقت": "show_time",
    ".حاسبة": "calculate",
}
def resolve_command(text: str):
    if not text:
        return None
    head = text.strip().split(maxsplit=1)[0]
    return ALLOWED_COMMANDS.get(head)
