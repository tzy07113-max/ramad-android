# -*- coding: utf-8 -*-
"""RAMAD AI - Royal Telegram assistant. Python 3.12 / python-telegram-bot 21.x"""
import os, re, io, ast, json, time, math, sqlite3, logging, asyncio, tempfile, textwrap
from datetime import datetime, timedelta, date
from urllib.parse import quote
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.constants import ChatMemberStatus
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from music.commands import MUSIC_COMMANDS

logging.basicConfig(level=os.getenv('LOG_LEVEL','INFO'), format='%(asctime)s %(levelname)s %(name)s: %(message)s')
log=logging.getLogger('ramad')
TOKEN=os.getenv('BOT_TOKEN','').strip(); OWNER_ID=int(os.getenv('OWNER_ID','0') or 0)
DB=os.getenv('RAMAD_DB','ramad.sqlite3'); COMMONS='https://commons.wikimedia.org/w/api.php'
SESSION=requests.Session(); SESSION.headers.update({'User-Agent':'RamadAI/1.0 (Telegram bot; educational project)'})

# ---------- persistence ----------
def db():
    c=sqlite3.connect(DB); c.execute('PRAGMA journal_mode=WAL'); return c
def init_db():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS chat_text(chat INTEGER,key TEXT,value TEXT,PRIMARY KEY(chat,key));
        CREATE TABLE IF NOT EXISTS notes(uid INTEGER, note TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, task TEXT, done INTEGER DEFAULT 0, created TEXT);
        CREATE TABLE IF NOT EXISTS warnings(chat INTEGER, uid INTEGER, count INTEGER DEFAULT 0, PRIMARY KEY(chat,uid));
        CREATE TABLE IF NOT EXISTS stats(key TEXT PRIMARY KEY, value INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS settings(chat INTEGER PRIMARY KEY, welcome TEXT DEFAULT 'أهلاً بك في مجموعتنا 👑');''')
def bump(key):
    with db() as c: c.execute('INSERT INTO stats VALUES(?,1) ON CONFLICT(key) DO UPDATE SET value=value+1',(key,))
def is_owner(uid): return bool(OWNER_ID and uid==OWNER_ID)
async def admin(update, ctx):
    if not update.effective_chat or not update.effective_user: return False
    try:
        m=await ctx.bot.get_chat_member(update.effective_chat.id,update.effective_user.id)
        return m.status in (ChatMemberStatus.ADMINISTRATOR,ChatMemberStatus.OWNER)
    except Exception: return False
async def require_admin(update,ctx):
    if not await admin(update,ctx): await update.effective_message.reply_text('⛔ هذا الأمر للمشرفين فقط.'); return False
    return True
async def target_from_reply(update):
    m=update.effective_message
    return m.reply_to_message.from_user if m and m.reply_to_message else None

# ---------- royal menus ----------
CATEGORIES={
'♛ عرش الملوك':'/start · .حسابي · .معرفي · .حالة رماد · .عن رماد · .أوامري · .مساعدة',
'🜲 عالم الظلال':'.بحث · .معلومة · .ويكيبيديا · .معنى · .مرادف · .طقس مدينة · .وقت دولة',
'⚜ مختبر العباقرة':'.ذكاء نصك · .ترجم النص · .لخص النص · .صحح النص · .اشرح النص · .أعد الصياغة',
'🔮 البوابة السحرية':'.صوره وصف · .فيديو وصف · .صوت وصف · .بحث كلمة · .QR نص · .زخرف نص · .تحسين (بالرد على صورة)',
'👁 عين الصقر':'.فحص رابط · .قوة كلمة · .معلومات تقنية · .حماية حسابي · .تعلم شبكات',
'🎁 سوق الهدايا':'.pp رابط الهدية · .فلور رابط الهدية (أرضية المجموعة اليومية من Fragment)',
'⚔ ساحة الأساطير':'.نكتة · .حكمة · .اقتباس · .لغز · .تحدي · .XO (ترفيه نصي)',
'🏛 مملكة الأدوات':'.حاسبة عملية · .عملة 10 USD SAR · .تحويل وحدات · .احسب العمر تاريخ · .تاريخ',
'🗝 خزائن الأسرار':'.ملاحظة نص · .ملاحظاتي · .أضف مهمة · .مهامي · .إنجاز رقم',
'🛡 حصن الحماية':'.تحذير (رد) · .تحذيراتي · .حظر (رد) · .فك_حظر ID · .كتم دقائق (رد) · .فك_كتم (رد) · .حذف عدد',
'👑 غرفة التحكم العليا':'.إحصائيات رماد · .فحص النظام · .وضع الصيانة تشغيل/إيقاف (مالك)'}
def main_keyboard():
    keys=list(CATEGORIES)
    rows=[[InlineKeyboardButton(keys[i],callback_data=f'cat:{i}'),InlineKeyboardButton(keys[i+1],callback_data=f'cat:{i+1}')] for i in range(0,len(keys)-1,2)]
    if len(keys)%2: rows.append([InlineKeyboardButton(keys[-1],callback_data=f'cat:{len(keys)-1}')])
    rows.append([InlineKeyboardButton('✦ عن رماد ✦',callback_data='about')])
    return InlineKeyboardMarkup(rows)
async def start(update,ctx):
    bump('starts')
    caption=('╔═══『 𓆩 ♛ RAMAD AI ♛ 𓆪 』═══╗\n\n'
      '        ✦ مملكة الذكاء والإبداع ✦\n'
      '  ⚜ أسود فحمي • ذهبي • أبيض ⚜\n\n'
      'اختر بوابتك من القوائم أدناه.\nاكتب .أوامري لعرض دليل الأوامر.\n'
      '╚════════════════════════════╝')
    try:
        with open(os.path.join(os.path.dirname(__file__),'ramad_banner.png'),'rb') as f:
            await update.effective_message.reply_photo(f,caption=caption,reply_markup=main_keyboard())
    except Exception: await update.effective_message.reply_text(caption,reply_markup=main_keyboard())

async def show_id(update,ctx):
    if update.effective_user:
        await update.effective_message.reply_text(f'🆔 Telegram ID: {update.effective_user.id}')

async def menu_callback(update,ctx):
    q=update.callback_query; await q.answer()
    if q.data=='about': await q.edit_message_caption(caption='𓆩 RAMAD AI 𓆪\nمساعد متعدد الأدوات. بعض الخدمات تتطلب اتصالاً بالإنترنت أو مفاتيح API.',reply_markup=main_keyboard()); return
    if q.data.startswith('cat:'):
        i=int(q.data.split(':')[1]); name=list(CATEGORIES)[i]
        await q.edit_message_caption(caption=f'╭─── 𓆩 {name} 𓆪 ───╮\n\n{CATEGORIES[name]}\n\nأرسل الأمر مع المطلوب بعده.\n╰────────────────╯',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('↩ الرئيسية',callback_data='home')]]))
    elif q.data=='home': await q.edit_message_caption(caption='𓆩 ♛ RAMAD AI ♛ 𓆪\nاختر أحد الأقسام الملكية:',reply_markup=main_keyboard())

# ---------- safe helpers ----------
def safe_calc(expr):
    tree=ast.parse(expr,mode='eval'); allowed=(ast.Expression,ast.BinOp,ast.UnaryOp,ast.Constant,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.FloorDiv,ast.Mod,ast.Pow,ast.USub,ast.UAdd,ast.Load)
    if any(not isinstance(n,allowed) for n in ast.walk(tree)): raise ValueError('عملية غير مسموحة')
    def ev(n):
        if isinstance(n,ast.Expression): return ev(n.body)
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)): return n.value
        if isinstance(n,ast.UnaryOp): return -ev(n.operand) if isinstance(n.op,ast.USub) else ev(n.operand)
        a,b=ev(n.left),ev(n.right)
        if isinstance(n.op,ast.Add): return a+b
        if isinstance(n.op,ast.Sub): return a-b
        if isinstance(n.op,ast.Mult): return a*b
        if isinstance(n.op,ast.Div): return a/b
        if isinstance(n.op,ast.FloorDiv): return a//b
        if isinstance(n.op,ast.Mod): return a%b
        if isinstance(n.op,ast.Pow) and abs(b)<=8: return a**b
        raise ValueError('عملية غير مدعومة')
    result=ev(tree)
    if not math.isfinite(float(result)) or abs(result)>1e100: raise ValueError('النتيجة خارج النطاق')
    return result

def http_json(url,params=None):
    r=SESSION.get(url,params=params,timeout=18); r.raise_for_status(); return r.json()
def commons_search(q,kind='bitmap',limit=5):
    data=http_json(COMMONS,{'action':'query','format':'json','generator':'search','gsrsearch':f'filetype:{kind} {q}','gsrnamespace':6,'gsrlimit':limit,'prop':'imageinfo','iiprop':'url|mime|size'})
    out=[]
    for p in data.get('query',{}).get('pages',{}).values():
        inf=(p.get('imageinfo') or [{}])[0]; url=inf.get('url'); mime=inf.get('mime','')
        if url and ((kind=='bitmap' and mime.startswith('image/')) or (kind=='video' and mime.startswith('video/')) or (kind=='audio' and mime.startswith('audio/'))): out.append({'title':p.get('title','Media'),'url':url,'size':inf.get('size',0),'mime':mime})
    return out
def download(url,limit=20*1024*1024):
    r=SESSION.get(url,stream=True,timeout=30); r.raise_for_status(); out=io.BytesIO(); total=0
    for ch in r.iter_content(65536):
        total+=len(ch)
        if total>limit: return None
        out.write(ch)
    return out.getvalue()

async def media_search(update,ctx,q,kind):
    if not q: await update.effective_message.reply_text('اكتب وصفاً بعد الأمر. مثال: .صوره قطط'); return
    m=update.effective_message; await m.reply_text('🔎 جارٍ البحث عن الوسائط...')
    try: files=await asyncio.to_thread(commons_search,q,kind,6)
    except Exception: log.exception('commons search'); await m.reply_text('تعذر البحث حالياً. حاول لاحقاً.'); return
    sent=0
    for f in files:
        try:
            lim=10*1024*1024 if kind=='bitmap' else 20*1024*1024
            if f['size'] and f['size']>lim: continue
            raw=await asyncio.to_thread(download,f['url'],lim)
            if not raw: continue
            bio=io.BytesIO(raw)
            ext='.jpg' if kind=='bitmap' else '.mp4' if kind=='video' else ('.mp3' if 'mpeg' in f.get('mime','') else '.ogg' if 'ogg' in f.get('mime','') else '.wav' if 'wav' in f.get('mime','') else '.audio')
            bio.name='ramad_media'+ext
            if kind=='bitmap': await ctx.bot.send_photo(m.chat_id,bio,caption=f['title'][:900])
            elif kind=='video': await ctx.bot.send_video(m.chat_id,bio,caption=f['title'][:900])
            else:
                try: await ctx.bot.send_audio(m.chat_id,bio,caption=f['title'][:900])
                except Exception: bio.seek(0); await ctx.bot.send_document(m.chat_id,bio,caption='🎧 '+f['title'][:850])
            sent+=1
            if sent >= (3 if kind=='bitmap' else 1): break
        except Exception: log.exception('send media')
    if not sent: await m.reply_text('لم أجد ملفاً مناسباً يمكن إرساله مباشرةً. جرّب وصفاً آخر أو صيغة أبسط.')

async def text_search(q):
    data=http_json('https://ar.wikipedia.org/w/api.php',{'action':'query','format':'json','list':'search','srsearch':q,'srlimit':5,'srprop':'snippet'})
    rows=data.get('query',{}).get('search',[])
    if not rows: return 'لم تظهر نتائج نصية مناسبة. جرّب كلمات أخرى.'
    out=['🔎 نتائج البحث عن: '+q]
    for i,row in enumerate(rows,1):
        snippet=re.sub(r'<[^>]+>','',row.get('snippet',''))
        out.append(f"\n{i}. {row.get('title','نتيجة')}\n{snippet}")
    return '\n'.join(out)[:3900]

async def wiki(q):
    d=http_json('https://ar.wikipedia.org/w/api.php',{'action':'query','format':'json','prop':'extracts','exintro':1,'explaintext':1,'redirects':1,'titles':q})
    pages=d.get('query',{}).get('pages',{}); p=next(iter(pages.values()),{})
    return p.get('extract','لم أجد مقالة بهذا العنوان.')[:3500]
async def weather(city):
    g=http_json('https://geocoding-api.open-meteo.com/v1/search',{'name':city,'count':1,'language':'ar','format':'json'})
    if not g.get('results'): return 'لم أجد المدينة.'
    x=g['results'][0]; w=http_json('https://api.open-meteo.com/v1/forecast',{'latitude':x['latitude'],'longitude':x['longitude'],'current':'temperature_2m,relative_humidity_2m,wind_speed_10m','timezone':'auto'})['current']
    return f"🌤 الطقس في {x['name']}:\nالحرارة: {w['temperature_2m']}°C\nالرطوبة: {w['relative_humidity_2m']}%\nالرياح: {w['wind_speed_10m']} كم/س"
async def currency(amount,src,dst):
    d=http_json(f'https://api.frankfurter.app/latest',{'amount':amount,'from':src.upper(),'to':dst.upper()})
    return f"💱 {amount:g} {src.upper()} = {d['rates'][dst.upper()]:,.4f} {dst.upper()}\nالتاريخ: {d['date']}"

GIFT_FLOORS_URL='https://atlannn.github.io/telegram-gifts-floor-price/api/v1/latest.json'
def gift_floor_info(query):
    # Daily collection floor snapshot; this is not an individual sale quote.
    data=http_json(GIFT_FLOORS_URL)
    floors=data.get('floors',{})
    raw=query.lower()
    slug=next((k for k in sorted(floors,key=len,reverse=True) if k in raw),None)
    if not slug:
        from urllib.parse import urlparse
        path=urlparse(query).path.lower()
        slug=next((k for k in sorted(floors,key=len,reverse=True) if k in path),None)
    if not slug:
        return None
    row=floors[slug]
    gram=row.get('floor_gram')
    if gram is None: return None
    fixed=row.get('floor_fixed_gram')
    usd=row.get('floor_usd')
    eur=row.get('floor_eur')
    lines=[f'🎁 أرضية مجموعة {slug}',f'أقل سعر معلن: {gram:g} GRAM']
    lines.append(f'أقل سعر ثابت: {fixed:g} GRAM' if fixed is not None else 'أقل سعر ثابت: لا توجد بيانات')
    if usd is not None: lines.append(f'القيمة التقريبية: ${usd:,.2f}')
    if eur is not None: lines.append(f'القيمة التقريبية: €{eur:,.2f}')
    lines += [f'تاريخ البيانات: {data.get("date","غير محدد")}',
              f'العروض التي شملها الرصد: {row.get("lots_seen",0)} (حد الرصد 60 عرضاً)',
              'المصدر: Fragment عبر مجموعة بيانات Baltic Assets — السعر المعروض ليس سعر بيع مؤكد ولا يشمل الرسوم.']
    return '\n'.join(lines)

# ---------- command engine ----------
ALIASES={'.إحصائيات':'.إحصائيات رماد','.صورة':'.صوره','.صور':'.صوره','.موسيقى':'.صوت','.اغنية':'.صوت','.أغنية':'.صوت','.زخرف اسمي':'.زخرف','.معرفي':'.id','.مساعدة':'.أوامري','.معلومة':'.معلومة'}

async def run_extra(cmd,arg,update,ctx,actor_id):
    m=update.effective_message; ch=update.effective_chat; user=update.effective_user
    def reply_target(): return m.reply_to_message.from_user if m.reply_to_message else None
    if cmd=='.تحدي':
        import random
        await m.reply_text('🎯 تحديك اليوم: تعلم معلومة جديدة وشاركها مع صديقك.'); return True
    if cmd=='.نسخ': await m.reply_text(arg[:3900] if arg else 'اكتب النص بعد الأمر.'); return True
    if cmd=='.عكس': await m.reply_text(arg[::-1] if arg else 'اكتب نصاً بعد الأمر.'); return True
    if cmd=='.عدد_الحروف': await m.reply_text(f'عدد الحروف: {len(arg.replace(" ",""))}'); return True
    if cmd=='.عدد_الكلمات': await m.reply_text(f'عدد الكلمات: {len(arg.split())}'); return True
    if cmd=='.تنظيف': await m.reply_text(re.sub(r'\s+',' ',arg).strip() if arg else 'اكتب النص المراد تنظيفه.'); return True
    if cmd=='.تنسيق': await m.reply_text(f'『 {arg} 』\n𓆩 {arg} 𓆪\n✦彡 {arg} 彡✦' if arg else 'اكتب النص.'); return True
    if cmd=='.حروف': await m.reply_text(' '.join(arg) if arg else 'اكتب كلمة.'); return True
    if cmd=='.اختيار':
        opts=[x.strip() for x in re.split(r'[|،,]',arg) if x.strip()]
        if len(opts)<2: await m.reply_text('مثال: .اختيار شاي | قهوة')
        else:
            import random
            await m.reply_text('🎯 الاختيار: '+random.choice(opts))
        return True
    if cmd in ('.نسبة','.خصم','.زيادة','.مقارنة'):
        try:
            a,b=map(float,arg.replace(',',' ').split()[:2])
            if cmd=='.نسبة': out=f'{a:g} من {b:g} = {(a/b*100 if b else 0):.2f}%'
            elif cmd=='.خصم': out=f'السعر بعد الخصم: {a-(a*b/100):.2f}'
            elif cmd=='.زيادة': out=f'القيمة بعد الزيادة: {a+(a*b/100):.2f}'
            else: out='الأول أكبر' if a>b else 'الثاني أكبر' if b>a else 'متساويان'
            await m.reply_text(out)
        except Exception: await m.reply_text('مثال: .خصم 200 15')
        return True
    if cmd in ('.متوسط','.اكبر','.اصغر','.ترتيب'):
        try:
            nums=[float(x) for x in re.split(r'[ ,،]+',arg.strip()) if x]
            if not nums: raise ValueError()
            out=(f'المتوسط: {sum(nums)/len(nums):g}' if cmd=='.متوسط' else
                 f'الأكبر: {max(nums):g}' if cmd=='.اكبر' else
                 f'الأصغر: {min(nums):g}' if cmd=='.اصغر' else
                 'الترتيب: '+'، '.join(f'{x:g}' for x in sorted(nums)))
            await m.reply_text(out)
        except Exception: await m.reply_text('أدخل أرقاماً مفصولة بمسافات.')
        return True
    if cmd=='.تحويل_حرارة':
        try:
            v,u=arg.split()[:2]; v=float(v); u=u.upper()
            if u=='C': out=f'{v:g}°C = {v*9/5+32:.2f}°F'
            elif u=='F': out=f'{v:g}°F = {(v-32)*5/9:.2f}°C'
            else: raise ValueError()
            await m.reply_text(out)
        except Exception: await m.reply_text('مثال: .تحويل_حرارة 25 C')
        return True
    if cmd in ('.تحويل_طول','.تحويل_كيلومتر'):
        try:
            v,u=arg.split()[:2]; v=float(v); f={'m':1,'km':1000,'cm':.01,'mm':.001}[u.lower()]
            meters=v*f; await m.reply_text(f'{meters:g} متر | {meters/1000:g} كم | {meters*100:g} سم')
        except Exception: await m.reply_text('مثال: .تحويل_طول 2 km (m, km, cm, mm)')
        return True
    if cmd=='.تحويل_وزن':
        try:
            v,u=arg.split()[:2]; v=float(v); kg=v if u.lower()=='kg' else v/1000 if u.lower()=='g' else v*1000 if u.lower()=='ton' else None
            if kg is None: raise ValueError()
            await m.reply_text(f'{kg:g} كجم | {kg*1000:g} جرام | {kg/1000:g} طن')
        except Exception: await m.reply_text('مثال: .تحويل_وزن 500 g (kg, g, ton)')
        return True
    if cmd=='.تحويل_ميجا':
        try:
            v=float(arg); await m.reply_text(f'{v:g} MB = {v*1024:g} KB = {v/1024:.4f} GB')
        except Exception: await m.reply_text('مثال: .تحويل_ميجا 5')
        return True
    if cmd=='.فرق_تاريخ':
        try:
            a,b=[date.fromisoformat(x) for x in arg.split()[:2]]
            await m.reply_text(f'الفرق: {abs((b-a).days)} يوم')
        except Exception: await m.reply_text('مثال: .فرق_تاريخ 2026-01-01 2026-12-31')
        return True
    if cmd=='.أيام_متبقية':
        try: await m.reply_text(f'المتبقي: {(date.fromisoformat(arg)-date.today()).days} يوم')
        except Exception: await m.reply_text('مثال: .أيام_متبقية 2026-12-31')
        return True
    if cmd in ('.اليوم','.تاريخ_اليوم','.تقويم'):
        d=date.today(); days=['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد']
        await m.reply_text(f'📅 {days[d.weekday()]}\n{d.isoformat()}\nالشهر {d.month} | السنة {d.year}'); return True
    if cmd in ('.وقت_السعودية','.الساعة','.توقيت'):
        try:
            from zoneinfo import ZoneInfo
            zone=arg or 'Asia/Riyadh'; await m.reply_text(datetime.now(ZoneInfo(zone)).strftime(zone+'\n%Y-%m-%d %H:%M:%S'))
        except Exception: await m.reply_text('مثال: .توقيت Asia/Riyadh')
        return True
    if cmd=='.عمر_بالأيام':
        try: await m.reply_text(f'الفارق: {(date.today()-date.fromisoformat(arg)).days} يوم')
        except Exception: await m.reply_text('مثال: .عمر_بالأيام 2000-01-01')
        return True
    if cmd=='.مولد_لون':
        import random
        await m.reply_text('🎨 لون عشوائي: #{:06X}'.format(random.randint(0,0xFFFFFF))); return True
    if cmd=='.رابط_بحث':
        if not arg: await m.reply_text('مثال: .رابط_بحث تعلم بايثون')
        else: await m.reply_text('https://www.google.com/search?q='+quote(arg),disable_web_page_preview=True)
        return True
    if cmd in ('.منشن_الرد','.معرف_الرد','.اسم_الرد','.معلومات_الرد'):
        t=reply_target()
        if not t: await m.reply_text('استخدم الأمر بالرد على رسالة شخص.'); return True
        out=(f'@{t.username}' if t.username else t.full_name) if cmd=='.منشن_الرد' else f'ID: {t.id}' if cmd=='.معرف_الرد' else t.full_name if cmd=='.اسم_الرد' else f'الاسم: {t.full_name}\nID: {t.id}\nالمعرف: @{t.username or "غير متاح"}'
        await m.reply_text(out); return True
    if cmd=='.معلومات_المجموعة':
        await m.reply_text('هذا الأمر يعمل داخل المجموعات.' if ch.type=='private' else f'الاسم: {ch.title}\nID: {ch.id}\nالنوع: {ch.type}'); return True
    if cmd=='.عدد_الأعضاء':
        if ch.type=='private': await m.reply_text('هذا الأمر يعمل داخل المجموعات.')
        else:
            try: await m.reply_text(f'عدد الأعضاء: {await ctx.bot.get_chat_member_count(ch.id)}')
            except Exception: await m.reply_text('تعذر جلب العدد.')
        return True
    if cmd=='.رابط_المجموعة':
        if ch.type=='private': await m.reply_text('هذا الأمر يعمل داخل المجموعات.')
        else:
            try: await m.reply_text(ch.invite_link or await ctx.bot.export_chat_invite_link(ch.id))
            except Exception: await m.reply_text('يحتاج البوت صلاحية دعوة المستخدمين.')
        return True
    if cmd=='.قوانين':
        with db() as con: row=con.execute("SELECT value FROM chat_text WHERE chat=? AND key='rules'",(ch.id,)).fetchone()
        await m.reply_text(row[0] if row else 'لم تُحدد قوانين لهذه المجموعة.'); return True
    if cmd in ('.تعيين_قوانين','.تعيين_ترحيب'):
        if not await require_admin(update,ctx): return True
        if not arg: await m.reply_text('اكتب النص بعد الأمر.'); return True
        with db() as con:
            if cmd=='.تعيين_قوانين': con.execute("INSERT INTO chat_text VALUES(?,?,?) ON CONFLICT(chat,key) DO UPDATE SET value=excluded.value",(ch.id,'rules',arg))
            else:
                con.execute("INSERT INTO settings(chat,welcome) VALUES(?,?) ON CONFLICT(chat) DO UPDATE SET welcome=excluded.welcome",(ch.id,arg))
        await m.reply_text('تم حفظ الإعداد.'); return True
    if cmd in ('.تثبيت','.الغاء_تثبيت'):
        if not await require_admin(update,ctx): return True
        if not m.reply_to_message: await m.reply_text('استخدم الأمر بالرد على الرسالة.')
        else:
            try:
                if cmd=='.تثبيت': await ctx.bot.pin_chat_message(ch.id,m.reply_to_message.message_id)
                else: await ctx.bot.unpin_chat_message(ch.id,m.reply_to_message.message_id)
                await m.reply_text('تم التنفيذ.')
            except Exception: await m.reply_text('تحقق من صلاحيات تثبيت الرسائل.')
        return True
    if cmd in ('.قفل','.فتح'):
        if not await require_admin(update,ctx): return True
        try:
            await ctx.bot.set_chat_permissions(ch.id,ChatPermissions(can_send_messages=(cmd=='.فتح')))
            await m.reply_text('تم فتح الإرسال.' if cmd=='.فتح' else 'تم قفل الإرسال للأعضاء.')
        except Exception: await m.reply_text('تعذر تغيير الصلاحيات.')
        return True
    if cmd=='.حذف_ملاحظة':
        try:
            idx=int(arg)-1
            with db() as con:
                rows=con.execute('SELECT rowid FROM notes WHERE uid=? ORDER BY rowid DESC',(actor_id,)).fetchall()
                if idx<0 or idx>=len(rows): raise ValueError()
                con.execute('DELETE FROM notes WHERE rowid=?',(rows[idx][0],))
            await m.reply_text('تم حذف الملاحظة.')
        except Exception: await m.reply_text('اكتب رقم الملاحظة بعد الأمر.')
        return True
    if cmd=='.مسح_ملاحظاتي':
        with db() as con: con.execute('DELETE FROM notes WHERE uid=?',(actor_id,))
        await m.reply_text('تم مسح ملاحظاتك.'); return True
    if cmd=='.حذف_مهمة':
        try:
            with db() as con: cur=con.execute('DELETE FROM tasks WHERE id=? AND uid=?',(int(arg),actor_id))
            await m.reply_text('تم حذف المهمة.' if cur.rowcount else 'لم أجد المهمة.')
        except Exception: await m.reply_text('مثال: .حذف_مهمة 3')
        return True
    if cmd=='.مسح_مهامي':
        with db() as con: con.execute('DELETE FROM tasks WHERE uid=?',(actor_id,))
        await m.reply_text('تم مسح مهامك.'); return True
    if cmd=='.حالة_البوت':
        await m.reply_text('𓆩 RAMAD AI 𓆪\nالحالة: متصل\nالنسخة: V5\nقاعدة البيانات: SQLite'); return True
    if cmd=='.وقت_تشغيل':
        started=ctx.application.bot_data.setdefault('started_at',time.monotonic()); sec=int(time.monotonic()-started)
        await m.reply_text(f'مدة التشغيل: {sec//3600} ساعة و{(sec%3600)//60} دقيقة'); return True
    if cmd in ('.مساعدة_سريعة','.تعليمات'):
        await m.reply_text('اكتب .أوامري لعرض الدليل. أوامر المجموعة تحتاج صلاحيات مناسبة.'); return True
    if cmd=='.مسح_التحذيرات':
        if not await require_admin(update,ctx): return True
        if not m.reply_to_message: await m.reply_text('استخدم الأمر بالرد على العضو.')
        else:
            with db() as con: con.execute('DELETE FROM warnings WHERE chat=? AND uid=?',(ch.id,m.reply_to_message.from_user.id))
            await m.reply_text('تم مسح تحذيرات العضو.')
        return True
    return False

async def handle_dot(update,ctx):
    msg=update.effective_message; user=update.effective_user; chat=update.effective_chat
    if not msg or not msg.text or not chat: return
    # أوامر الاستخدام العام متاحة لكل مستخدم؛ تُحمى أوامر المالك والإدارة
    # كلٌ على حدة داخل معالجها. منشورات القنوات لا تملك هوية مستخدم شخصية.
    if not user:
        await msg.reply_text('هذه الميزة تحتاج حساب مستخدم مرسلاً للأمر، ولا تعمل على منشورات القنوات.')
        return
    actor_id = user.id
    parts=msg.text.strip().split(maxsplit=1); cmd=ALIASES.get(parts[0],parts[0]); arg=parts[1].strip() if len(parts)>1 else ''
    if cmd in MUSIC_COMMANDS:
        await msg.reply_text('🎧 مكتبة موسيقى رماد مضافة إلى الحزمة، لكن محرك مكالمات تيليجرام والحساب المساعد لم يُربطا بعد. لن أدّعي أن التشغيل يعمل قبل إعداد الحساب واختبار PyTgCalls على الاستضافة.')
        return
    bump(cmd)
    if await run_extra(cmd,arg,update,ctx,actor_id): return
    if cmd in ('.pp','.فلور'):
        if not arg:
            await msg.reply_text('أرسل رابط هدية Fragment أو اسم المجموعة. مثال: .pp https://fragment.com/gift/plushpepe-1')
            return
        try:
            result=await asyncio.to_thread(gift_floor_info,arg)
            await msg.reply_text(result or 'لم أتعرف على مجموعة الهدية من الرابط. أرسل رابط Fragment واضحاً أو اسم المجموعة بالإنجليزية.')
        except Exception:
            log.exception('gift floor lookup')
            await msg.reply_text('تعذر جلب أسعار الهدايا الآن. حاول لاحقاً.')
        return
    if cmd=='.ا':
        target=msg.reply_to_message.from_user if msg.reply_to_message else user
        details=[f'👤 الاسم: {target.full_name}',f'🆔 المعرف الرقمي: {target.id}',
                 f'🔗 اسم المستخدم: @{target.username}' if target.username else '🔗 اسم المستخدم: غير متاح',
                 f'🌐 اللغة: {target.language_code}' if target.language_code else '🌐 اللغة: غير متاحة',
                 f'🤖 حساب آلي: {"نعم" if target.is_bot else "لا"}',
                 '🎁 الهدايا: لا يوفر Telegram Bot API سجلاً موثوقاً للهدايا لهذا الحساب.',
                 '📅 تاريخ إنشاء الحساب: غير متاح عبر Telegram Bot API']
        caption='╭─ 𓆩 بطاقة الحساب 𓆪 ─╮\n'+'\n'.join(details)+'\n╰────────────────╯'
        try:
            photos=await ctx.bot.get_user_profile_photos(target.id,limit=1)
            if photos.total_count and photos.photos:
                await ctx.bot.send_photo(chat_id=msg.chat_id,photo=photos.photos[0][-1].file_id,caption=caption,reply_to_message_id=msg.message_id)
            else: await msg.reply_text(caption)
        except Exception: await msg.reply_text(caption)
        return
    if cmd in ('.أوامري','.help'):
        txt='𓆩 ♛ دليل أوامر رماد ♛ 𓆪\n'+'\n'.join(f'\n{name}\n{commands}' for name,commands in CATEGORIES.items())
        await msg.reply_text(txt[:3900]); return
    if cmd=='.حسابي':
        if not user: await msg.reply_text('هذا منشور قناة؛ لا يوجد حساب شخصي مرسل للأمر.'); return
        await msg.reply_text(f'👤 {user.full_name}\nالمعرف: @{user.username or "لا يوجد"}\nID: {user.id}'); return
    if cmd=='.id': await msg.reply_text((f'🆔 User: {user.id}\n' if user else '📰 منشور قناة\n')+f'Chat: {msg.chat_id}'); return
    if cmd in ('.ping','.حالة رماد'): await msg.reply_text('🏓 رماد يعمل بنجاح.'); return
    if cmd=='.عن رماد': await msg.reply_text('𓆩 RAMAD AI 𓆪\nمساعد تيليجرام متعدد الأدوات.'); return
    if cmd=='.بحث':
        if not arg: await msg.reply_text('مثال: .بحث الأمن السيبراني'); return
        try: await msg.reply_text(await asyncio.to_thread(text_search,arg))
        except Exception: await msg.reply_text('تعذر البحث النصي حالياً. حاول لاحقاً.')
        return
    if cmd=='.صوره': await media_search(update,ctx,arg,'bitmap'); return
    if cmd=='.فيديو': await media_search(update,ctx,arg,'video'); return
    if cmd=='.صوت': await media_search(update,ctx,arg,'audio'); return
    if cmd in ('.ويكيبيديا','.معنى','.معلومة'):
        if not arg: await msg.reply_text('اكتب الموضوع بعد الأمر.'); return
        try: await msg.reply_text(await wiki(arg))
        except Exception: await msg.reply_text('تعذر جلب المعلومة الآن.'); return
        return
    if cmd=='.طقس':
        if not arg: await msg.reply_text('مثال: .طقس الرياض'); return
        try: await msg.reply_text(await weather(arg))
        except Exception: await msg.reply_text('تعذر جلب الطقس لهذه المدينة.'); return
        return
    if cmd=='.عملة':
        p=arg.split()
        if len(p)!=3: await msg.reply_text('الصيغة: .عملة 10 USD SAR'); return
        try: await msg.reply_text(await currency(float(p[0]),p[1],p[2]))
        except Exception: await msg.reply_text('تعذر التحويل. تحقق من المبلغ ورمزي العملتين.'); return
        return
    if cmd=='.حاسبة':
        try: await msg.reply_text(f'🧮 النتيجة: {safe_calc(arg)}')
        except Exception: await msg.reply_text('صيغة غير صحيحة. مثال: .حاسبة (25*4)+10')
        return
    if cmd=='.تاريخ': await msg.reply_text(datetime.now().strftime('📅 %Y-%m-%d\n🕒 %H:%M:%S')); return
    if cmd=='.وقت': await msg.reply_text(datetime.now().strftime('🕒 %H:%M:%S')); return
    if cmd=='.احسب العمر':
        try:
            born=date.fromisoformat(arg); today=date.today(); years=today.year-born.year-((today.month,today.day)<(born.month,born.day)); await msg.reply_text(f'عمرك التقريبي: {years} سنة')
        except Exception: await msg.reply_text('اكتب التاريخ هكذا: .احسب العمر 2005-04-21')
        return
    if cmd=='.زخرف':
        if not arg: await msg.reply_text('اكتب النص بعد الأمر.'); return
        styles=[f'『 {arg} 』',f'𓆩 {arg} 𓆪',f'✦彡 {arg} 彡✦',f'꧁༺ {arg} ༻꧂',f'♛ {arg} ♛']
        await msg.reply_text('\n'.join(styles)); return
    if cmd=='.QR':
        if not arg: await msg.reply_text('اكتب نصاً أو رابطاً بعد .QR'); return
        try:
            import qrcode
            im=qrcode.make(arg); b=io.BytesIO(); b.name='ramad_qr.png'; im.save(b,format='PNG'); b.seek(0); await ctx.bot.send_photo(msg.chat_id,b,caption='𓆩 QR بواسطة رماد 𓆪')
        except ImportError: await msg.reply_text('ميزة QR تحتاج تثبيت qrcode[pil].')
        return
    if cmd=='.قوة كلمة':
        if not arg: await msg.reply_text('اكتب كلمة اختبارية غير مستخدمة في حساباتك.'); return
        score=sum([len(arg)>=12, bool(re.search('[a-z]',arg)),bool(re.search('[A-Z]',arg)),bool(re.search('[0-9]',arg)),bool(re.search(r'[^A-Za-z0-9]',arg))])
        await msg.reply_text(f'تقييم تقريبي: {score}/5\nلا ترسل كلمة مرورك الحقيقية إلى أي بوت.'); return
    if cmd=='.فحص رابط':
        if not re.match(r'^https?://',arg,re.I): await msg.reply_text('أرسل رابطاً يبدأ بـ https:// أو http://'); return
        try:
            from urllib.parse import urlparse
            p=urlparse(arg); await msg.reply_text(f'🔗 النطاق: {p.hostname}\nالاتصال المشفر: {p.scheme=="https"}\nهذا فحص شكلي فقط ولا يضمن سلامة الموقع.')
        except Exception: await msg.reply_text('تعذر تحليل الرابط.')
        return
    if cmd=='.ملاحظة':
        if not arg: await msg.reply_text('اكتب الملاحظة بعد الأمر.'); return
        with db() as c: c.execute('INSERT INTO notes VALUES(?,?,?)',(actor_id,arg,datetime.utcnow().isoformat()))
        await msg.reply_text('🗝 حفظت ملاحظتك الخاصة.'); return
    if cmd=='.ملاحظاتي':
        with db() as c: rows=c.execute('SELECT note,created FROM notes WHERE uid=? ORDER BY rowid DESC LIMIT 15',(actor_id,)).fetchall()
        await msg.reply_text('🗝 ملاحظاتك:\n'+'\n'.join(f'{i+1}. {r[0]}' for i,r in enumerate(rows)) if rows else 'لا توجد ملاحظات محفوظة.'); return
    if cmd=='.أضف مهمة':
        if not arg: await msg.reply_text('اكتب المهمة.'); return
        with db() as c: c.execute('INSERT INTO tasks(uid,task,created) VALUES(?,?,?)',(actor_id,arg,datetime.utcnow().isoformat()))
        await msg.reply_text('✓ أضيفت المهمة إلى قائمتك.'); return
    if cmd=='.مهامي':
        with db() as c: rows=c.execute('SELECT id,task,done FROM tasks WHERE uid=? ORDER BY id DESC LIMIT 20',(actor_id,)).fetchall()
        await msg.reply_text('📋 مهامك:\n'+'\n'.join(f"{i}. {'✓' if d else '○'} {t}" for i,t,d in rows) if rows else 'قائمة المهام فارغة.'); return
    if cmd=='.إنجاز':
        try:
            tid=int(arg)
            with db() as c: cur=c.execute('UPDATE tasks SET done=1 WHERE id=? AND uid=?',(tid,actor_id))
            await msg.reply_text('✓ تم تحديث المهمة.' if cur.rowcount else 'لم أجد مهمة بهذا الرقم.')
        except Exception: await msg.reply_text('الصيغة: .إنجاز رقم_المهمة')
        return
    if cmd=='.نكتة': await msg.reply_text('لماذا يحب المبرمج الهدوء؟ لأنه لا يريد أخطاءً غير متوقعة! 😄'); return
    if cmd=='.حكمة': await msg.reply_text('الاستمرار بخطوات صغيرة يصنع فرقاً كبيراً.'); return
    if cmd=='.اقتباس': await msg.reply_text('«ابدأ بما تستطيع، ومن حيث أنت، وبما تملك».'); return
    if cmd=='.لغز': await msg.reply_text('ما الشيء الذي كلما أخذت منه كبر؟\nالجواب: الحفرة.'); return
    if cmd in ('.ترجم','.لخص','.صحح','.اشرح','.ذكاء'):
        if not arg: await msg.reply_text('اكتب النص بعد الأمر.'); return
        key=os.getenv('OPENAI_API_KEY')
        if not key: await msg.reply_text('هذه الخدمة تحتاج إضافة OPENAI_API_KEY في إعدادات الاستضافة حتى تعمل.'); return
        prompt={'.ترجم':'ترجم النص إلى العربية مع الحفاظ على المعنى: ','.لخص':'لخص النص التالي بنقاط واضحة: ','.صحح':'صحح النص لغوياً وإملائياً: ','.اشرح':'اشرح النص التالي بأسلوب مبسط: ','.ذكاء':'أجب عن الطلب التالي بوضوح: '}[cmd]
        try:
            r=SESSION.post('https://api.openai.com/v1/chat/completions',headers={'Authorization':f'Bearer {key}'},json={'model':os.getenv('OPENAI_MODEL','gpt-4o-mini'),'messages':[{'role':'user','content':prompt+arg}]},timeout=45); r.raise_for_status(); out=r.json()['choices'][0]['message']['content']; await msg.reply_text(out[:4000])
        except Exception: log.exception('AI API'); await msg.reply_text('تعذر الاتصال بخدمة الذكاء الاصطناعي. تحقق من المفتاح والرصيد.')
        return
    if cmd in ('.حالة الخدمات','.فحص النظام'):
        await msg.reply_text('🛠 النظام يعمل.\nقاعدة البيانات: متاحة\nالذاكرة: SQLite\nخدمات الإنترنت: تعتمد على توفر المصدر الخارجي.'); return
    if cmd=='.إحصائيات رماد':
        if not user or not is_owner(user.id): await msg.reply_text('هذا الأمر للمالك فقط.'); return
        with db() as c: rows=c.execute('SELECT key,value FROM stats ORDER BY value DESC LIMIT 20').fetchall()
        await msg.reply_text('👑 إحصائيات رماد:\n'+'\n'.join(f'{k}: {v}' for k,v in rows)); return
    if cmd=='.وضع الصيانة':
        if not user or not is_owner(user.id): await msg.reply_text('هذا الأمر للمالك فقط.'); return
        ctx.application.bot_data['maintenance']=arg.lower() in ('تشغيل','on','1','تفعيل')
        await msg.reply_text('تم تفعيل وضع الصيانة.' if ctx.application.bot_data['maintenance'] else 'تم إيقاف وضع الصيانة.'); return
    # group moderation commands
    if cmd in ('.تحذير','.حظر','.فك_كتم','.تحذيراتي','.كتم','.فك_حظر','.حذف'):
        if not await require_admin(update,ctx): return
        target=await target_from_reply(update)
        if cmd=='.تحذيراتي':
            with db() as c: row=c.execute('SELECT count FROM warnings WHERE chat=? AND uid=?',(msg.chat_id,actor_id)).fetchone()
            await msg.reply_text(f'تحذيراتك: {row[0] if row else 0}'); return
        if cmd=='.فك_حظر':
            if not arg.isdigit(): await msg.reply_text('الصيغة: .فك_حظر user_id'); return
            try: await ctx.bot.unban_chat_member(msg.chat_id,int(arg)); await msg.reply_text('تم فك الحظر إن كان العضو محظوراً.')
            except Exception: await msg.reply_text('تعذر فك الحظر؛ تحقق من صلاحيات البوت.')
            return
        if cmd=='.حذف':
            try:
                n=max(1,min(int(arg or '1'),50)); count=0
                for mid in range(msg.message_id-1,msg.message_id-n-1,-1):
                    try: await ctx.bot.delete_message(msg.chat_id,mid); count+=1
                    except Exception: pass
                await msg.reply_text(f'حذفت {count} رسالة.')
            except Exception: await msg.reply_text('الصيغة: .حذف 10')
            return
        if not target: await msg.reply_text('استخدم الأمر بالرد على رسالة العضو.'); return
        if cmd=='.تحذير':
            with db() as c:
                c.execute('INSERT INTO warnings VALUES(?,?,1) ON CONFLICT(chat,uid) DO UPDATE SET count=count+1',(msg.chat_id,target.id))
                n=c.execute('SELECT count FROM warnings WHERE chat=? AND uid=?',(msg.chat_id,target.id)).fetchone()[0]
            await msg.reply_text(f'⚠️ تحذير {target.full_name}: {n}/3'); return
        if cmd=='.حظر':
            try: await ctx.bot.ban_chat_member(msg.chat_id,target.id); await msg.reply_text('تم حظر العضو.')
            except Exception: await msg.reply_text('تعذر الحظر؛ تحقق من صلاحيات البوت.')
            return
        if cmd=='.كتم':
            try:
                mins=max(1,min(int(arg or '10'),1440)); await ctx.bot.restrict_chat_member(msg.chat_id,target.id,permissions=ChatPermissions(can_send_messages=False),until_date=timedelta(minutes=mins)); await msg.reply_text(f'تم كتم العضو {mins} دقيقة.')
            except Exception: await msg.reply_text('تعذر الكتم؛ تحقق من صلاحيات البوت.')
            return
        if cmd=='.فك_كتم':
            try: await ctx.bot.restrict_chat_member(msg.chat_id,target.id,permissions=ChatPermissions(can_send_messages=True,can_send_photos=True,can_send_videos=True,can_send_documents=True,can_send_audios=True,can_send_voice_notes=True,can_send_video_notes=True,can_send_polls=True,can_send_other_messages=True,can_add_web_page_previews=True)); await msg.reply_text('تم فك الكتم.')
            except Exception: await msg.reply_text('تعذر فك الكتم.')
            return
    # Commands that require extra integrations are listed transparently
    await msg.reply_text('هذا الأمر موجود ضمن دليل رماد لكنه يحتاج ربط خدمة إضافية أو لم يُفعّل بعد. اكتب .أوامري لمعرفة الخدمات المتاحة.')

async def anti_spam(update,ctx):
    m=update.effective_message; u=update.effective_user; ch=update.effective_chat
    if not m or not u or not ch or ch.type=='private' or not m.text: return
    try:
        member=await ctx.bot.get_chat_member(ch.id,u.id)
        if member.status in (ChatMemberStatus.ADMINISTRATOR,ChatMemberStatus.OWNER): return
    except Exception: return
    now=time.monotonic(); key=(ch.id,u.id); data=ctx.application.bot_data.setdefault('spam',{})
    q=data.setdefault(key,[]); q[:]=[t for t in q if now-t<8]; q.append(now)
    if len(q)>=8:
        try: await m.delete(); await ctx.bot.restrict_chat_member(ch.id,u.id,permissions=ChatPermissions(can_send_messages=False),until_date=timedelta(minutes=2)); q.clear()
        except Exception: log.exception('antispam')
async def welcome(update,ctx):
    m=update.effective_message
    if not m or not m.new_chat_members: return
    with db() as c: row=c.execute('SELECT welcome FROM settings WHERE chat=?',(m.chat_id,)).fetchone()
    template=row[0] if row else 'أهلاً بك في مجموعتنا 👑'
    for member in m.new_chat_members:
        if not member.is_bot: await m.reply_text(f'{template}\n{member.full_name}')
async def error_handler(update,ctx): log.exception('Unhandled bot error',exc_info=ctx.error)

async def post_init(app):
    commands=[('start','القائمة الرئيسية'),('help','المساعدة'),('ping','فحص البوت'),('id','معرف الحساب')]
    try: await app.bot.set_my_commands(commands)
    except Exception: log.exception('set commands')

def main():
    if not TOKEN: raise RuntimeError('BOT_TOKEN غير مضبوط في متغيرات الاستضافة.')
    init_db(); app=Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler('start',start)); app.add_handler(CommandHandler('help',start)); app.add_handler(CommandHandler('ping',lambda u,c: u.effective_message.reply_text('🏓 رماد يعمل.'))); app.add_handler(CommandHandler('id',show_id))
    app.add_handler(CallbackQueryHandler(menu_callback))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS,welcome),group=0)
    # slash moderation aliases
    for name,fn in [('warn',None),('warnings',None),('ban',None),('unban',None),('mute',None),('unmute',None),('purge',None)]: pass
    dot_commands=r'^\.(?:أوامري|help|حسابي|id|معرفي|ping|حالة\ رماد|عن\ رماد|بحث|صوره|صورة|صور|فيديو|صوت|موسيقى|اغنية|أغنية|ويكيبيديا|معنى|معلومة|طقس|عملة|حاسبة|تاريخ|وقت|احسب\ العمر|زخرف|زخرف\ اسمي|QR|قوة\ كلمة|فحص\ رابط|ملاحظة|ملاحظاتي|أضف\ مهمة|مهامي|إنجاز|نكتة|حكمة|اقتباس|لغز|ترجم|لخص|صحح|اشرح|ذكاء|حالة\ الخدمات|فحص\ النظام|إحصائيات\ رماد|وضع\ الصيانة|تحذير|حظر|فك_كتم|تحذيراتي|كتم|فك_حظر|حذف|ا|عكس|عدد_الحروف|عدد_الكلمات|تنظيف|اختيار|نسبة|خصم|زيادة|متوسط|اكبر|اصغر|ترتيب|تحويل_حرارة|تحويل_طول|تحويل_وزن|فرق_تاريخ|أيام_متبقية|اليوم|وقت_السعودية|منشن_الرد|معرف_الرد|اسم_الرد|معلومات_المجموعة|عدد_الأعضاء|رابط_المجموعة|قوانين|تعيين_قوانين|تعيين_ترحيب|تثبيت|الغاء_تثبيت|قفل|فتح|حذف_ملاحظة|مسح_ملاحظاتي|حذف_مهمة|مسح_مهامي|نسخ|رابط_بحث|حالة_البوت|وقت_تشغيل|مساعدة_سريعة|تنسيق|حروف|تحويل_كيلومتر|تحويل_ميجا|تقويم|معلومات_الرد|الساعة|تاريخ_اليوم|مقارنة|توقيت|عمر_بالأيام|مولد_لون|مسح_التحذيرات|تحدي|تعليمات|تشغيل|ايقاف|تخطي|استئناف|كتم|الغاء_الكتم|قائمة|مغادرة|pp|فلور)(?:\s+.*)?$'
    # Text commands work in private chats, groups/supergroups, and channel posts.
    app.add_handler(MessageHandler(filters.TEXT & filters.Regex(dot_commands),handle_dot),group=1)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,anti_spam),group=2)
    app.add_error_handler(error_handler)
    log.info('RAMAD AI started'); app.run_polling(allowed_updates=Update.ALL_TYPES)
if __name__=='__main__': main()
