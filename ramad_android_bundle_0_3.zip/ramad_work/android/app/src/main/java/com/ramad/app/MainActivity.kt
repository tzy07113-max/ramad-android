package com.ramad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090A0D)
private val Panel = Color(0xFF15171D)
private val Gold = Color(0xFFD6B46A)
private val Muted = Color(0xFF9A9DA6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RamadApp() }
    }
}

data class Module(val title: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun RamadApp() {
    var selected by remember { mutableStateOf("الرئيسية") }
    val modules = listOf(
        Module("مركز الأوامر", "إدارة أوامر النقطة", Icons.Default.Terminal),
        Module("الحساب الشخصي", "الملف والمعلومات المتاحة", Icons.Default.AccountCircle),
        Module("البحث والوسائط", "بحث وصور وفيديو", Icons.Default.Search),
        Module("المجموعات والقنوات", "أدوات وفق الصلاحيات", Icons.Default.Groups),
        Module("مركز الأدوات", "إضافات رماد", Icons.Default.Build),
        Module("الاشتراكات", "الخطة وحالة التفعيل", Icons.Default.WorkspacePremium),
        Module("الإعدادات", "الاتصال والمظهر واللغة", Icons.Default.Settings),
        Module("مركز المساعدة", "الدليل وحالة الخدمات", Icons.Default.Help)
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Gold,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                listOf("الرئيسية", "الأوامر", "الحساب", "الإعدادات").forEach { item ->
                    NavigationBarItem(
                        selected = selected == item,
                        onClick = { selected = item },
                        icon = { Icon(when(item) {
                            "الأوامر" -> Icons.Default.Terminal
                            "الحساب" -> Icons.Default.Person
                            "الإعدادات" -> Icons.Default.Settings
                            else -> Icons.Default.Home
                        }, contentDescription = item) },
                        label = { Text(item, fontSize = 10.sp) }
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Ink).padding(padding).padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("𓆩 ♛ RAMAD ♛ 𓆪", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black)
                        Text("مركز التحكم الذكي", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50), border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha=.45f))) {
                        Text("نسخة تأسيسية 0.1", color = Gold, modifier = Modifier.padding(horizontal=12.dp, vertical=8.dp), fontSize=10.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha=.35f))) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("أهلاً بك في رماد", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("كل أدواتك في مركز واحد، بتصميم قابل للتطوير.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0xFF3B2E16), shape = RoundedCornerShape(30.dp)) {
                                Text("● غير مربوط بالخادم", color = Gold, modifier = Modifier.padding(horizontal=12.dp, vertical=7.dp), fontSize=11.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text("اربط الخادم لتفعيل الخدمات", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text(if (selected == "الرئيسية") "أقسام رماد" else selected, color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(modules) { module ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().height(122.dp).clickable { selected = module.title },
                            color = Panel, shape = RoundedCornerShape(18.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha=.18f))
                        ) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Icon(module.icon, contentDescription = null, tint = Gold, modifier = Modifier.size(26.dp))
                                Column {
                                    Text(module.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(module.subtitle, color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
