package com.ramad.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090711)
private val Panel = Color(0xFF171222)
private val Violet = Color(0xFF9B63FF)
private val Gold = Color(0xFFE8C879)
private val Muted = Color(0xFFB8AEC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RamadApp() }
    }
}

@Composable
fun RamadApp() {
    var page by remember { mutableStateOf("الرئيسية") }
    var prompt by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("مرحبًا بك في رماد AI. أنا مساعدك، وهذه نسخة البداية من التطبيق.")) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Violet,
        secondary = Gold, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF100C19))
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf("الرئيسية", "المساعد", "المملكة", "حسابي").forEach { item ->
                        Column(
                            Modifier.weight(1f).clickable { page = item }.padding(5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                when (item) { "الرئيسية" -> "⌂"; "المساعد" -> "✦"; "المملكة" -> "♛"; else -> "◉" },
                                color = if (page == item) Gold else Muted, fontSize = 21.sp
                            )
                            Text(item, color = if (page == item) Gold else Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .background(Brush.verticalGradient(listOf(Color(0xFF171022), Ink)))
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("𓆩 RAMAD AI 𓆪", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("عالمك الذكي • الإصدار 0.3", color = Muted, fontSize = 11.sp)
                    }
                    Text("✧", color = Violet, fontSize = 30.sp)
                }
                Spacer(Modifier.height(22.dp))
                when (page) {
                    "الرئيسية" -> HomeScreen { page = it }
                    "المساعد" -> {
                        Text("المساعد الذكي", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("مساحتك للمحادثة والأفكار", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(messages) { msg -> LuxuryCard { Text(msg, color = Color.White, fontSize = 14.sp) } }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BasicTextField(
                                value = prompt, onValueChange = { prompt = it },
                                modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).padding(15.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                                decorationBox = { inner -> if (prompt.isEmpty()) Text("اكتب رسالتك هنا...", color = Muted); inner() }
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                if (prompt.isNotBlank()) {
                                    messages = messages + "أنت: $prompt" + "رماد: وصلت رسالتك. ربط الذكاء الاصطناعي الفعلي سيكون في خطوة الاتصال بالخدمة."
                                    prompt = ""
                                }
                            }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("إرسال") }
                        }
                    }
                    "المملكة" -> KingdomScreen()
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(open: (String) -> Unit) {
    LuxuryCard {
        Text("مرحبًا بك في مملكتك", color = Gold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text("رماد AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Text("ذكاء • إبداع • أدواتك في مكان واحد", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { open("المساعد") }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            Text("ابدأ المحادثة  ✦")
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("بوابتك السريعة", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    listOf("المساعد" to "✦ محادثة ذكية", "المملكة" to "♛ مركز الأوامر", "حسابي" to "◉ بطاقة العضوية").forEach { (dest, label) ->
        LuxuryCard(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { open(dest) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text("‹", color = Gold, fontSize = 24.sp)
            }
        }
    }
    Spacer(Modifier.weight(1f))
    Text("RAMAD AI  •  ROYAL EDITION", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}

@Composable
fun KingdomScreen() {
    Text("مملكة الأوامر", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Text("اختر القسم لاستكشاف أدوات رماد", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(16.dp))
    val tools = listOf("الذكاء الاصطناعي" to "✦", "مركز الصور" to "▧", "مركز الفيديو" to "▷", "مركز الصوت" to "♫", "الأدوات" to "⚙", "الإعدادات" to "◇")
    tools.chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            pair.forEach { (name, icon) ->
                LuxuryCard(Modifier.weight(1f).padding(bottom = 10.dp).height(112.dp).clickable { }) {
                    Text(icon, color = Gold, fontSize = 25.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
    Text("سيتم تفعيل خدمات الوسائط والاتصالات في مراحل الربط التالية.", color = Muted, fontSize = 11.sp)
}

@Composable
fun ProfileScreen() {
    Text("بطاقتي الملكية", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(16.dp))
    LuxuryCard(Modifier.fillMaxWidth()) {
        Text("✧", color = Gold, fontSize = 36.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("عضوية رماد", color = Gold, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("مستخدم رماد", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text("ملفك الشخصي", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("0", "النشاط")
            Stat("0", "الهدايا")
            Stat("0", "الإنجازات")
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("يمكن تخصيص الاسم والصورة والنبذة عند إضافة إعدادات الملف الشخصي.", color = Muted, fontSize = 12.sp)
}

@Composable
fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun LuxuryCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.background(Panel, RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFF49365F), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}
